# AduinoSocketIo
Socket.io client and server library for Arduino
